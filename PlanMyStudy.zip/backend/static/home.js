// ── Timer ──
let time=0,interval=null;
const timerEl=document.getElementById('timer');
function startTimer(){if(interval)return;interval=setInterval(()=>{time++;timerEl.textContent=String(Math.floor(time/60)).padStart(2,'0')+':'+String(time%60).padStart(2,'0');},1000);}
function pauseTimer(){clearInterval(interval);interval=null;}
function resetTimer(){pauseTimer();time=0;timerEl.textContent='00:00';}

// ── Sessions ──
async function addSession(){
  const sub=document.getElementById('subject');
  const dur=document.getElementById('duration');
  if(!sub.value||!dur.value)return;
  const res=await fetch('/api/sessions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:sub.value,duration:parseInt(dur.value)})});
  const s=await res.json();
  const li=document.createElement('li');
  li.style='list-style:none;background:rgba(116,198,157,.15);border-left:3px solid var(--accent);color:var(--text);padding:8px 10px;margin-top:5px;border-radius:8px;display:flex;justify-content:space-between;align-items:center;';
  li.innerHTML=`<span>${s.name} – ${s.duration} min</span><button style="width:auto;padding:2px 8px;background:rgba(255,107,107,.2);color:#e05252;border:none;border-radius:5px;cursor:pointer;" onclick="deleteSession(${s.id},this)">✕</button>`;
  document.getElementById('sessions').appendChild(li);
  sub.value='';dur.value='';
}

async function deleteSession(id,btn){
  await fetch('/api/sessions/'+id,{method:'DELETE'});
  btn.parentElement.remove();
}

// ── Calendar ──
const calEl=document.getElementById('homeCalGrid');
const monthYearEl=document.getElementById('monthYear');
let current=new Date(),selected=null,events={};
const today=new Date();

async function loadCalendarEvents(){events=await fetch('/api/calendar').then(r=>r.json());renderCalendar();}

function renderCalendar(){
  calEl.innerHTML='';
  const y=current.getFullYear(),m=current.getMonth();
  monthYearEl.textContent=current.toLocaleString('default',{month:'long',year:'numeric'});
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>{const div=document.createElement('div');div.className='day-name';div.textContent=d;calEl.appendChild(div);});
  const start=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();
  for(let i=0;i<start;i++)calEl.appendChild(document.createElement('div'));
  for(let d=1;d<=days;d++){
    const key=`${y}-${m}-${d}`;
    const isToday=d===today.getDate()&&m===today.getMonth()&&y===today.getFullYear();
    const div=document.createElement('div');
    div.className='day'+(isToday?' today':'')+(key===selected?' selected':'');
    div.dataset.key=key;
    const num=document.createElement('span');num.textContent=d;div.appendChild(num);
    if(events[key]?.length){const dot=document.createElement('div');dot.className='dot';div.appendChild(dot);}
    div.onclick=()=>selectDate(key,div);calEl.appendChild(div);
  }
  renderEvents();
}

function selectDate(key,el){
  document.querySelectorAll('#homeCalGrid .day.selected').forEach(d=>d.classList.remove('selected'));
  if(selected===key){
    selected=null;
    document.getElementById('calHint').textContent='Click a date to add an event';
    document.getElementById('homeEventInputRow').style.display='none';
  }else{
    selected=key;el.classList.add('selected');
    const parts=key.split('-');
    const dt=new Date(+parts[0],+parts[1],+parts[2]);
    document.getElementById('calHint').textContent=dt.toLocaleDateString('default',{day:'numeric',month:'short',year:'numeric'});
    document.getElementById('homeEventInputRow').style.display='block';
    document.getElementById('eventText').focus();
  }
  renderEvents();
}

function changeMonth(n){current.setMonth(current.getMonth()+n);renderCalendar();}

async function addEvent(){
  const txt=document.getElementById('eventText');
  if(!selected||!txt.value.trim())return;
  const res=await fetch('/api/calendar',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({date_key:selected,text:txt.value.trim()})});
  const e=await res.json();
  if(!events[selected])events[selected]=[];
  events[selected].push({id:e.id,text:e.text});
  txt.value='';renderCalendar();
  document.querySelector(`#homeCalGrid .day[data-key="${selected}"]`)?.classList.add('selected');
}

function renderEvents(){
  const list=document.getElementById('eventList');list.innerHTML='';
  if(!selected)return;
  (events[selected]||[]).forEach(e=>{
    const item=document.createElement('div');item.className='home-event-item';
    item.innerHTML=`<span>${e.text}</span><button class="home-event-del" onclick="deleteEvent(${e.id},'${selected}')">✕</button>`;
    list.appendChild(item);
  });
}

async function deleteEvent(id,key){
  await fetch('/api/calendar/'+id,{method:'DELETE'});
  events[key]=events[key].filter(e=>e.id!==id);
  renderCalendar();
  if(selected)document.querySelector(`#homeCalGrid .day[data-key="${selected}"]`)?.classList.add('selected');
}

document.getElementById('eventText').addEventListener('keydown',e=>{if(e.key==='Enter')addEvent();});
loadCalendarEvents();

// ── Modules ──
async function loadModules(){
  const mods=await fetch('/api/modules').then(r=>r.json());
  const container=document.getElementById('modulesContainer');
  container.innerHTML='';
  if(!mods.length){container.innerHTML=`<div style="color:#aaa;font-size:.85rem;">No modules yet. <a href="/modules" style="color:var(--accent)">Add one →</a></div>`;return;}
  mods.forEach(m=>{
    const div=document.createElement('div');
    div.style.cssText='background:rgba(116,198,157,.15);border-left:4px solid var(--accent);padding:8px 12px;border-radius:8px;margin-bottom:8px;cursor:pointer;transition:.15s;';
    div.onmouseenter=()=>div.style.background='rgba(116,198,157,.25)';
    div.onmouseleave=()=>div.style.background='rgba(116,198,157,.15)';
    div.onclick=()=>window.location.href=`/modules#module-${m.id}`;
    let inner=`<div style="font-weight:600;font-family:'Poppins',sans-serif;font-size:.9rem;color:var(--text);">${m.name}</div>`;
    if(m.submodules?.length)inner+=`<div style="margin-top:4px;">`+m.submodules.map(s=>`<div style="font-size:.78rem;color:var(--subtext);padding:1px 0;">↳ ${s.name}</div>`).join('')+`</div>`;
    div.innerHTML=inner;container.appendChild(div);
  });
}
loadModules();

// ── Onboarding ──
let obStep=0;
const OB_TOTAL=5;
function obAdvance(){
  if(obStep<OB_TOTAL-1){
    document.getElementById('step-'+obStep).style.display='none';
    obStep++;
    document.getElementById('step-'+obStep).style.display='block';
    document.querySelectorAll('.ob-dot').forEach((d,i)=>d.classList.toggle('active',i===obStep));
    if(obStep===OB_TOTAL-1)document.getElementById('obNext').textContent="Let's go! 🚀";
  }else{closeOnboarding();}
}
function closeOnboarding(){
  document.getElementById('onboardingOverlay').style.display='none';
  fetch('/api/onboarding-done',{method:'POST'});
}
