let activePanel='login';

function togglePw(inputId,btn){
  const inp=document.getElementById(inputId);
  const showing=inp.type==='text';
  inp.type=showing?'password':'text';
  btn.innerHTML=showing?'<i class="fa fa-eye"></i>':'<i class="fa fa-eye-slash"></i>';
}

function showLogin(tab){
  activePanel='login';
  document.querySelectorAll('.auth-tab').forEach(t=>t.classList.remove('active'));
  tab.classList.add('active');
  document.getElementById('loginPanel').style.display='block';
  document.getElementById('registerPanel').style.display='none';
}

function showRegister(tab){
  activePanel='register';
  document.querySelectorAll('.auth-tab').forEach(t=>t.classList.remove('active'));
  tab.classList.add('active');
  document.getElementById('loginPanel').style.display='none';
  document.getElementById('registerPanel').style.display='block';
}

async function doLogin(){
  const username=document.getElementById('loginUsername').value.trim();
  const password=document.getElementById('loginPassword').value;
  const errEl=document.getElementById('loginError');
  errEl.style.display='none';
  if(!username||!password){errEl.textContent='Enter your username and password.';errEl.style.display='block';return;}
  const data=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})}).then(r=>r.json());
  if(data.ok)window.location.href=data.redirect;
  else{errEl.textContent=data.error;errEl.style.display='block';}
}

async function doRegister(){
  const username=document.getElementById('registerUsername').value.trim();
  const password=document.getElementById('registerPassword').value;
  const errEl=document.getElementById('registerError');
  errEl.style.display='none';
  if(!username||!password){errEl.textContent='Fill in all fields.';errEl.style.display='block';return;}
  if(password.length<6){errEl.textContent='Password must be at least 6 characters.';errEl.style.display='block';return;}
  const data=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})}).then(r=>r.json());
  if(data.ok)window.location.href=data.redirect;
  else{errEl.textContent=data.error;errEl.style.display='block';}
}

document.addEventListener('keydown',e=>{
  if(e.key!=='Enter')return;
  if(activePanel==='login')doLogin();else doRegister();
});
