let focusSessionId=null,timerInterval=null,currentFileUrl=null;
const moduleIdMap={};

function esc(t){return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/'/g,'&#39;');}

// ── Calculator ──
let calcVal='0',calcPrev=null,calcOperator=null,calcReset=false;
function calcDisplay(v){document.getElementById('calcDisplay').textContent=v;}
function calcNum(n){if(calcReset){calcVal=n;calcReset=false;}else calcVal=calcVal==='0'?n:(calcVal.length<12?calcVal+n:calcVal);calcDisplay(calcVal);}
function calcDot(){if(calcReset){calcVal='0.';calcReset=false;}else if(!calcVal.includes('.'))calcVal+='.';calcDisplay(calcVal);}
function calcOp(op){calcPrev=parseFloat(calcVal);calcOperator=op;calcReset=true;const sym={'+':'+','-':'−','*':'×','/':'÷'}[op];document.getElementById('calcExpr').textContent=`${calcPrev} ${sym}`;}
function calcEquals(){
  if(!calcOperator||calcPrev===null)return;
  const cur=parseFloat(calcVal);
  const res={'+':calcPrev+cur,'-':calcPrev-cur,'*':calcPrev*cur,'/':cur===0?'Error':calcPrev/cur}[calcOperator];
  document.getElementById('calcExpr').textContent='';
  calcVal=res==='Error'?'Error':String(parseFloat(res.toFixed(10)));
  calcDisplay(calcVal);calcOperator=null;calcPrev=null;calcReset=true;
}
function calcClear(){calcVal='0';calcPrev=null;calcOperator=null;calcReset=false;calcDisplay('0');document.getElementById('calcExpr').textContent='';}
function calcSign(){calcVal=String(parseFloat(calcVal)*-1);calcDisplay(calcVal);}
function calcPercent(){calcVal=String(parseFloat(calcVal)/100);calcDisplay(calcVal);}
function toggleCalc(){
  const p=document.getElementById('calcPanel'),btn=document.getElementById('calcBtn');
  const show=p.style.display!=='block';
  p.style.display=show?'block':'none';
  btn.classList.toggle('tb-active',show);
}

// ── File viewer ──
function openFileInSession(url,name){
  currentFileUrl=url;
  document.getElementById('fileViewName').textContent=name;
  document.getElementById('timerView').style.display='none';
  document.getElementById('fileView').style.display='flex';
  const content=document.getElementById('fileViewContent');
  const ext=name.split('.').pop().toLowerCase();
  if(['png','jpg','jpeg','gif','webp'].includes(ext)){content.innerHTML=`<img src="${url}" alt="${esc(name)}">`;}
  else if(ext==='pdf'){content.innerHTML=`<iframe src="${url}" title="${esc(name)}"></iframe>`;}
  else{content.innerHTML=`<div style="text-align:center;padding:40px;color:var(--subtext);"><div style="font-size:3rem;margin-bottom:12px;">${fileIcon(name)}</div><div style="font-size:1rem;font-weight:600;margin-bottom:8px;">${esc(name)}</div><div style="font-size:.82rem;margin-bottom:20px;opacity:.7;">This file type can't be previewed. Download to open it.</div><button onclick="window.open('${url}')" style="padding:10px 22px;background:var(--accent);color:var(--on-accent,white);border:none;border-radius:8px;cursor:pointer;font-weight:700;">↓ Download File</button></div>`;}
}
function showTimerView(){document.getElementById('fileView').style.display='none';document.getElementById('timerView').style.display='flex';}
function downloadCurrentFile(){if(currentFileUrl)window.open(currentFileUrl);}

async function loadModules(){
  const modules=await fetch('/api/modules').then(r=>r.json());
  const sel=document.getElementById('moduleSelect');
  sel.innerHTML='<option value="" disabled selected>Select Module...</option>';
  modules.forEach(m=>{moduleIdMap[m.name]=m.id;const opt=document.createElement('option');opt.value=m.name;opt.textContent=m.name;sel.appendChild(opt);});
}

async function loadSessions(){
  const data=await fetch('/api/sessions').then(r=>r.json());
  document.getElementById('statPlanned').textContent=data.planned.length;
  document.getElementById('statCompleted').textContent=data.finished.length;
  const mins=data.planned.reduce((s,x)=>s+(x.duration||0),0);
  document.getElementById('statHours').textContent=mins>=60?(mins/60).toFixed(1)+'h':mins+'m';
  renderPlanned(data.planned);renderFinished(data.finished);
}

function renderPlanned(sessions){
  const list=document.getElementById('plannedList');
  if(!sessions.length){list.innerHTML='<div class="empty-msg">No planned sessions.</div>';return;}
  list.innerHTML='';
  sessions.forEach(s=>{
    const modId=moduleIdMap[s.module]||null;
    const div=document.createElement('div');div.className='session-item';div.id='session-'+s.id;
    div.innerHTML=`<div class="session-item-info"><div class="session-item-name">${esc(s.name)}</div><div class="session-item-meta">${esc(s.module||'')}${s.module&&s.type?' · ':''}${esc(s.type||'')} · ${s.duration}m</div></div><div class="session-item-btns"><button class="btn-sm start-btn" onclick="startFocus(${s.id},'${esc(s.name)}','${esc(s.module||'')}','${esc(s.type||'')}',${s.duration},${modId})">▶ Start</button><button class="btn-sm ss-del-btn" onclick="deleteSession(${s.id})"><i class="fa fa-trash"></i></button></div>`;
    list.appendChild(div);
  });
}

function renderFinished(sessions){
  const list=document.getElementById('finishedList');
  if(!sessions.length){list.innerHTML='<div class="empty-msg">No completed sessions yet.</div>';return;}
  list.innerHTML='';
  sessions.forEach(s=>{
    const div=document.createElement('div');div.className='session-item';div.id='session-fin-'+s.id;
    div.style.borderLeftColor='#4caf50';div.style.opacity='.8';
    div.innerHTML=`<div class="session-item-info"><div class="session-item-name">${esc(s.name)}</div><div class="session-item-meta">${esc(s.module||'')}${s.module?' · ':''}${s.duration}m</div></div><span class="fin-badge">✓ Done</span><div class="session-item-btns"><button class="btn-sm ss-del-btn" onclick="deleteSession(${s.id})"><i class="fa fa-trash"></i></button></div>`;
    list.appendChild(div);
  });
}

async function addSession(){
  const name=document.getElementById('sessionName').value.trim();
  const mod=document.getElementById('moduleSelect').value;
  const type=document.getElementById('sessionType').value;
  const dur=parseInt(document.getElementById('sessionDuration').value);
  if(!name||!mod||!dur||dur<1)return;
  await fetch('/api/sessions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,module:mod,type,duration:dur})});
  document.getElementById('sessionName').value='';document.getElementById('sessionDuration').value='';
  await loadSessions();
}

async function deleteSession(id){await fetch('/api/sessions/'+id,{method:'DELETE'});await loadSessions();}
async function completeSession(id){await fetch(`/api/sessions/${id}/complete`,{method:'POST'});}

async function startFocus(id,name,mod,type,duration,moduleId){
  focusSessionId=id;
  document.getElementById('focusTitle').textContent=name;
  document.getElementById('focusMod').textContent=mod||'';
  document.getElementById('focusType').textContent=type||'';
  document.getElementById('focusTypeMain').textContent=type||'';
  document.getElementById('focusOverlay').style.display='grid';
  document.getElementById('calcPanel').style.display='none';
  document.getElementById('calcBtn').classList.remove('tb-active');
  showTimerView();
  try{document.documentElement.requestFullscreen?.();}catch(e){}
  const fl=document.getElementById('focusFileList');
  fl.innerHTML='<div class="focus-no-files">Loading...</div>';
  if(moduleId&&moduleId!=='null'){
    try{
      const files=await fetch(`/api/module-files/${moduleId}`).then(r=>r.json());
      if(!files.length){fl.innerHTML='<div class="focus-no-files">No files for this module.</div>';}
      else{
        fl.innerHTML='';
        const imgExts=['png','jpg','jpeg','gif','webp'];
        files.forEach(f=>{
          const ext=(f.original_name||'').split('.').pop().toLowerCase();
          const url=`/uploads/${f.filename}`;
          if(imgExts.includes(ext)){
            const img=document.createElement('img');
            img.className='focus-img-thumb';img.src=url;img.alt=f.original_name;img.title=f.original_name;
            img.onclick=()=>{setActiveFile(img);openFileInSession(url,f.original_name);};fl.appendChild(img);
          }else{
            const item=document.createElement('div');item.className='focus-file-item';
            item.innerHTML=`<span>${fileIcon(f.original_name)}</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(f.original_name)}</span>`;
            item.onclick=()=>{setActiveFile(item);openFileInSession(url,f.original_name);};fl.appendChild(item);
          }
        });
      }
    }catch(e){fl.innerHTML='<div class="focus-no-files">Could not load files.</div>';}
  }else{fl.innerHTML='<div class="focus-no-files">No module selected.</div>';}
  let time=duration*60;const totalSecs=duration*60;
  clearInterval(timerInterval);updateTimer(time,totalSecs);
  timerInterval=setInterval(async()=>{
    time--;updateTimer(time,totalSecs);
    const pct=time/totalSecs;
    document.getElementById('timerHint').textContent=pct<.1?'🔥 Almost done!':pct<.5?'💪 Keep going!':'Stay focused 💪';
    if(time<=0){clearInterval(timerInterval);await completeSession(focusSessionId);exitFocus();loadSessions();}
  },1000);
}

function setActiveFile(el){
  document.querySelectorAll('.focus-img-thumb,.focus-file-item').forEach(x=>x.classList.remove('active-file'));
  el.classList.add('active-file');
}

function exitFocus(){
  clearInterval(timerInterval);
  document.getElementById('focusOverlay').style.display='none';
  document.getElementById('calcPanel').style.display='none';
  try{document.exitFullscreen?.();}catch(e){}
}

async function endFocusEarly(){if(focusSessionId)await completeSession(focusSessionId);exitFocus();loadSessions();}

function updateTimer(secs,totalSecs){
  if(secs<0)secs=0;
  const m=Math.floor(secs/60),s=secs%60;
  const str=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  document.getElementById('timerDisplay').textContent=str;
  const ft=document.getElementById('floatingTimer');if(ft)ft.textContent=str;
  document.getElementById('timerBar').style.width=(totalSecs>0?(secs/totalSecs)*100:0)+'%';
}

function fileIcon(name){
  const ext=(name||'').split('.').pop().toLowerCase();
  return{pdf:'📄',doc:'📝',docx:'📝',xls:'📊',xlsx:'📊',ppt:'📋',pptx:'📋',mp4:'🎬',mp3:'🎵',zip:'🗜️',txt:'📃'}[ext]||'📁';
}

loadModules().then(loadSessions);
