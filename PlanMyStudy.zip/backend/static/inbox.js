window.ME_ID=window.ME_ID||0;
localStorage.removeItem('inbox_unread');
const ME_ID=window.ME_ID;
const ME_NAME=window.ME_NAME||'';
let curType=null,curId=null,curCode=null,modalMode=null;
let sidePanelOpen=false,curSpTab='media';
let allMessages=[];

function esc(t){return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

const socket=io();
socket.on('connect',()=>socket.emit('join_notif'));
socket.on('new_dm',msg=>{
  if(msg.sender_id===ME_ID)return;
  if(curType==='dm'&&(msg.sender_id===curId||msg.receiver_id===curId)){allMessages.push(msg);addMsg(msg);}
  updatePreview(msg.sender_id,msg.file_path?'📎 File':msg.body);
  localStorage.setItem('inbox_unread','1');
});
socket.on('new_group_msg',msg=>{
  if(curType==='group'&&curId&&msg.sender_id!==ME_ID){allMessages.push(msg);addMsg(msg,true);}
});
socket.on('new_notif',data=>{
  if(data.type==='friend_request'){
    addRequestItem({id:data.req_id,from_id:data.from_id,from_name:data.from,from_avatar:data.from_avatar,created_at:'Just now'});
    bumpReqBadge(1);
  }
  localStorage.setItem('inbox_unread','1');
});
socket.on('friend_status',data=>{
  const dot=document.querySelector(`#dm-item-${data.user_id} [style*="border-radius:50%"]`);
  if(dot)dot.style.background=data.online?'#22c55e':'#ccc';
  if(curType==='dm'&&curId===data.user_id){
    const sub=document.getElementById('chatSub');
    if(sub)sub.textContent=data.online?'🟢 Online':'Offline';
  }
});

function updatePreview(senderId,text){
  const el=document.getElementById('dm-preview-'+senderId);
  if(el)el.textContent=text||'...';
}

function switchTab(tab,el){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('dmList').style.display=tab==='dms'?'block':'none';
  document.getElementById('groupList').style.display=tab==='groups'?'block':'none';
  document.getElementById('requestList').style.display=tab==='requests'?'block':'none';
  document.getElementById('dmActions').style.display=tab==='dms'?'flex':'none';
  document.getElementById('groupActions').style.display=tab==='groups'?'flex':'none';
  if(tab==='requests')loadRequests();
}

async function loadRequests(){
  const reqs=await fetch('/api/friend-requests').then(r=>r.json());
  const inner=document.getElementById('requestListInner');
  inner.innerHTML='';
  if(!reqs.length){inner.innerHTML='<div class="req-empty">No pending requests</div>';return;}
  reqs.forEach(r=>addRequestItem(r,false));
}

function addRequestItem(r,prepend=true){
  document.getElementById('noReqMsg')?.remove();
  const inner=document.getElementById('requestListInner');
  const el=document.createElement('div');
  el.className='req-item';el.id='req-'+r.id;
  const avatarHtml=r.from_avatar?`<img src="/uploads/${r.from_avatar}" style="width:100%;height:100%;object-fit:cover;">`:r.from_name[0].toUpperCase();
  el.innerHTML=`<div class="c-avatar">${avatarHtml}</div><div class="req-info"><div class="req-name">${esc(r.from_name)}</div><div class="req-sub">Friend request · ${r.created_at}</div></div><div class="req-btns"><button class="req-accept" onclick="acceptReq(${r.id},this)">✓</button><button class="req-decline" onclick="declineReq(${r.id},this)">✕</button></div>`;
  if(prepend)inner.prepend(el);else inner.appendChild(el);
}

async function acceptReq(id){
  const data=await fetch(`/api/friend-requests/${id}/accept`,{method:'POST'}).then(r=>r.json());
  document.getElementById('req-'+id)?.remove();
  bumpReqBadge(-1);
  if(!document.getElementById('requestListInner').children.length)
    document.getElementById('requestListInner').innerHTML='<div class="req-empty">No pending requests</div>';
  if(data.ok)addFriendItem({id:data.from_id,name:data.from_name,avatar:data.from_avatar,online:data.online,nickname:null});
}

async function declineReq(id){
  await fetch(`/api/friend-requests/${id}/decline`,{method:'POST'});
  document.getElementById('req-'+id)?.remove();
  bumpReqBadge(-1);
  if(!document.getElementById('requestListInner').children.length)
    document.getElementById('requestListInner').innerHTML='<div class="req-empty">No pending requests</div>';
}

function bumpReqBadge(delta){
  const badge=document.getElementById('reqBadge');
  if(!badge)return;
  const next=Math.max(0,(parseInt(badge.textContent)||0)+delta);
  badge.textContent=next;badge.style.display=next>0?'flex':'none';
}

async function openDM(uid,uname,avatarFile){
  curType='dm';curId=uid;allMessages=[];
  localStorage.removeItem('inbox_unread');
  socket.emit('join_dm',{other_id:uid});
  setActive('dm-item-'+uid);
  const ca=document.getElementById('chatAvatar');
  ca.className='c-avatar';
  ca.innerHTML=avatarFile?`<img src="/uploads/${avatarFile}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`:uname[0].toUpperCase();
  document.getElementById('chatName').textContent=uname;
  const dmItem=document.getElementById('dm-item-'+uid);
  const onlineDot=dmItem?.querySelector('[style*="border-radius:50%"]');
  document.getElementById('chatSub').textContent=onlineDot?.style.background?.includes('22c55e')?'🟢 Online':'Direct Message';
  document.getElementById('membersToggle').style.display='none';
  document.getElementById('spTabMembers').style.display='none';
  document.getElementById('settingsToggle').style.display='flex';
  document.getElementById('settingsPopup').classList.remove('show');
  document.getElementById('msgInput').placeholder='Message '+uname+'...';
  if(curSpTab==='members'){curSpTab='media';switchSpTab('media');}
  showChat();await loadMsgs();
  if(sidePanelOpen)renderSpTab();
}

async function openGroup(gid,gname,code){
  curType='group';curId=gid;curCode=code;allMessages=[];
  socket.emit('join_group',{group_id:gid});
  setActive('group-item-'+gid);
  const ca=document.getElementById('chatAvatar');
  ca.className='c-avatar group';ca.textContent=gname.slice(0,2).toUpperCase();
  document.getElementById('chatName').textContent=gname;
  document.getElementById('chatSub').textContent='';
  document.getElementById('membersToggle').style.display='flex';
  document.getElementById('spTabMembers').style.display='inline-block';
  document.getElementById('settingsToggle').style.display='none';
  document.getElementById('settingsPopup').classList.remove('show');
  document.getElementById('msgInput').placeholder='Message '+gname+'...';
  showChat();await loadMsgs();await loadMembers();
  if(sidePanelOpen)renderSpTab();
}

function setActive(id){
  document.querySelectorAll('.convo-item').forEach(i=>i.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
}

function showChat(){
  document.getElementById('emptyChat').style.display='none';
  const w=document.getElementById('activeChatWrap');
  w.style.display='flex';w.style.flexDirection='column';w.style.flex='1';w.style.minHeight='0';w.style.overflow='hidden';
}

async function loadMsgs(){
  const url=curType==='dm'?`/api/messages/${curId}`:`/api/groups/${curId}/messages`;
  const msgs=await fetch(url).then(r=>r.json());
  allMessages=msgs;
  const c=document.getElementById('chatMessages');
  c.innerHTML='';msgs.forEach(m=>addMsg(m,curType==='group'));c.scrollTop=c.scrollHeight;
}

function addMsg(msg,isGroup=false){
  const c=document.getElementById('chatMessages');
  const sent=msg.sender_id===ME_ID;
  const d=document.createElement('div');
  d.className='msg'+(sent?' sent':'');
  let body;
  if(msg.file_path&&msg.file_path!=='__pending__'){
    const isImg=/\.(png|jpg|jpeg|gif|webp)$/i.test(msg.file_path);
    body=isImg
      ?`<div class="file-bubble" onclick="window.open('/uploads/${msg.file_path}')"><img src="/uploads/${msg.file_path}" style="max-width:160px;max-height:120px;border-radius:8px;display:block"></div>`
      :`<div class="file-bubble" onclick="window.open('/uploads/${msg.file_path}')"><span style="font-size:1.1rem">📄</span><div><div class="f-name">${esc(msg.file_name||'File')}</div><div class="f-sub">Click to download</div></div></div>`;
  }else if(msg.file_path==='__pending__'){
    body=`<div class="file-bubble"><span style="font-size:1.1rem">⏳</span><div><div class="f-name">${esc(msg.file_name||'File')}</div><div class="f-sub">Uploading...</div></div></div>`;
  }else{body=`<div class="bubble">${esc(msg.body)}</div>`;}
  const avatarHtml=msg.sender_avatar?`<img src="/uploads/${msg.sender_avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`:(msg.sender_name||'?')[0].toUpperCase();
  d.innerHTML=`<div class="msg-avatar">${avatarHtml}</div><div class="msg-body">${!sent?`<div class="msg-sender">${esc(msg.sender_name)}</div>`:''} ${body}<div class="msg-time">${msg.timestamp}</div></div>`;
  c.appendChild(d);c.scrollTop=c.scrollHeight;
}

async function sendMessage(){
  const inp=document.getElementById('msgInput');
  const body=inp.value.trim();
  if(!body||!curId)return;
  inp.value='';
  const optimistic={sender_id:ME_ID,sender_name:ME_NAME,body,file_path:null,file_name:null,timestamp:new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})};
  allMessages.push(optimistic);addMsg(optimistic,curType==='group');
  const url=curType==='dm'?`/api/messages/${curId}`:`/api/groups/${curId}/messages`;
  const fd=new FormData();fd.append('body',body);
  fetch(url,{method:'POST',body:fd});
}

async function sendFile(){
  const file=document.getElementById('fileInput').files[0];
  if(!file||!curId)return;
  document.getElementById('fileInput').value='';
  const optimistic={sender_id:ME_ID,sender_name:ME_NAME,body:null,file_path:'__pending__',file_name:file.name,timestamp:new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})};
  allMessages.push(optimistic);addMsg(optimistic,curType==='group');
  const url=curType==='dm'?`/api/messages/${curId}`:`/api/groups/${curId}/messages`;
  const fd=new FormData();fd.append('file',file);
  const data=await fetch(url,{method:'POST',body:fd}).then(r=>r.json());
  const idx=allMessages.indexOf(optimistic);
  if(idx!==-1)allMessages[idx]=data;
}

document.getElementById('msgInput').addEventListener('keydown',e=>{if(e.key==='Enter')sendMessage();});

function toggleSidePanel(tab){
  if(sidePanelOpen&&curSpTab===tab){
    sidePanelOpen=false;
    document.getElementById('sidePanel').style.display='none';
    document.getElementById('mediaToggle').classList.remove('active-btn');
    document.getElementById('membersToggle').classList.remove('active-btn');
    return;
  }
  sidePanelOpen=true;curSpTab=tab;
  document.getElementById('sidePanel').style.display='flex';
  document.getElementById('mediaToggle').classList.toggle('active-btn',tab==='media');
  document.getElementById('membersToggle').classList.toggle('active-btn',tab==='members');
  switchSpTab(tab);
}

function switchSpTab(tab){
  curSpTab=tab;
  ['media','files','links','members'].forEach(t=>{
    const el=document.getElementById('spTab'+t[0].toUpperCase()+t.slice(1));
    if(el)el.classList.toggle('active',t===tab);
  });
  renderSpTab();
}

function renderSpTab(){
  const c=document.getElementById('spContent');
  if(curSpTab==='members'){loadMembersInPanel();return;}
  const imgExts=['png','jpg','jpeg','gif','webp'];
  const imgs=allMessages.filter(m=>m.file_path&&imgExts.some(e=>(m.file_path||'').toLowerCase().endsWith(e)));
  const files=allMessages.filter(m=>m.file_path&&!imgExts.some(e=>(m.file_path||'').toLowerCase().endsWith(e))&&m.file_path!=='__pending__');
  const links=[];
  allMessages.forEach(m=>{if(m.body){const found=m.body.match(/https?:\/\/[^\s]+/g);if(found)links.push(...found);}});
  if(curSpTab==='media')c.innerHTML=imgs.length?'<div class="media-grid">'+imgs.map(m=>`<div class="media-thumb" onclick="window.open('/uploads/${m.file_path}')"><img src="/uploads/${m.file_path}" alt=""></div>`).join('')+'</div>':'<div class="empty-media">No images yet</div>';
  else if(curSpTab==='files')c.innerHTML=files.length?files.map(m=>`<div class="media-file-item" onclick="window.open('/uploads/${m.file_path}')"><span style="font-size:1.2rem">📄</span><div><div style="font-weight:600">${esc(m.file_name||'File')}</div><div style="color:var(--subtext);font-size:.7rem">${m.timestamp}</div></div></div>`).join(''):'<div class="empty-media">No files yet</div>';
  else if(curSpTab==='links')c.innerHTML=links.length?'<div class="links-list">'+links.map(l=>`<a href="${esc(l)}" target="_blank">${esc(l)}</a>`).join('')+'</div>':'<div class="empty-media">No links yet</div>';
}

async function loadMembersInPanel(){
  if(curType!=='group')return;
  const members=await fetch(`/api/groups/${curId}/members`).then(r=>r.json());
  const c=document.getElementById('spContent');
  c.innerHTML=`<div class="members-title">Members (${members.length}/20)</div>${members.map(m=>`<div class="member-item"><div class="member-dot" style="background:${m.online?'var(--accent)':'#ccc'}"></div>${esc(m.name)}${m.id===ME_ID?' (you)':''}</div>`).join('')}<div class="invite-box"><div class="invite-label">Invite Code</div><div class="invite-code">${curCode}</div></div>`;
  document.getElementById('chatSub').textContent=members.length+' members';
}

async function loadMembers(){
  if(curType!=='group')return;
  const members=await fetch(`/api/groups/${curId}/members`).then(r=>r.json());
  document.getElementById('chatSub').textContent=members.length+' members';
}

function toggleSettings(e){e.stopPropagation();document.getElementById('settingsPopup').classList.toggle('show');}
document.addEventListener('click',()=>document.getElementById('settingsPopup').classList.remove('show'));

function openNicknameModal(){
  document.getElementById('settingsPopup').classList.remove('show');
  document.getElementById('nicknameOverlay').classList.add('show');
  document.getElementById('nicknameInput').value='';
  setTimeout(()=>document.getElementById('nicknameInput').focus(),100);
}

async function saveNickname(){
  const val=document.getElementById('nicknameInput').value.trim();
  const res=await fetch(`/api/friends/${curId}/nickname`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nickname:val})});
  const data=await res.json();
  if(!document.getElementById('chatName').dataset.realname)
    document.getElementById('chatName').dataset.realname=document.getElementById('chatName').textContent;
  const newLabel=data.nickname||document.getElementById('chatName').dataset.realname;
  document.getElementById('chatName').textContent=newLabel;
  document.getElementById('dm-item-'+curId)?.querySelector('.convo-name')&&(document.getElementById('dm-item-'+curId).querySelector('.convo-name').textContent=newLabel);
  document.getElementById('nicknameOverlay').classList.remove('show');
}

async function blockFriend(){
  if(!confirm('Block this user?'))return;
  await fetch(`/api/friends/${curId}/block`,{method:'POST'});
  _clearChat();
}

async function removeFriend(){
  if(!confirm('Remove this friend?'))return;
  await fetch(`/api/friends/${curId}`,{method:'DELETE'});
  _clearChat();
}

function _clearChat(){
  document.getElementById('dm-item-'+curId)?.remove();
  document.getElementById('emptyChat').style.display='flex';
  document.getElementById('activeChatWrap').style.display='none';
  document.getElementById('sidePanel').style.display='none';
  sidePanelOpen=false;curId=null;
}

function openModal(mode){
  modalMode=mode;
  document.getElementById('modalErr').style.display='none';
  document.getElementById('modalInput').value='';
  const cfg={add:{title:'Add Friend',ph:'Enter their username...'},create:{title:'Create Group',ph:'Group name...'},join:{title:'Join Group',ph:'Enter invite code...'}}[mode];
  document.getElementById('modalTitle').textContent=cfg.title;
  document.getElementById('modalInput').placeholder=cfg.ph;
  document.getElementById('modalOverlay').classList.add('show');
  setTimeout(()=>document.getElementById('modalInput').focus(),100);
}

function closeModal(){document.getElementById('modalOverlay').classList.remove('show');}

async function confirmModal(){
  const val=document.getElementById('modalInput').value.trim();
  const err=document.getElementById('modalErr');
  err.style.display='none';
  if(!val)return;
  if(modalMode==='add'){
    const data=await fetch('/api/friends/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:val})}).then(r=>r.json());
    if(data.error){err.textContent=data.error;err.style.display='block';return;}
    closeModal();
    if(data.sent)showToastInbox(`Friend request sent to ${data.to}!`);
  }else if(modalMode==='create'){
    const data=await fetch('/api/groups',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:val})}).then(r=>r.json());
    if(data.id){addGroupItem(data);closeModal();openGroup(data.id,data.name,data.invite_code);}
  }else if(modalMode==='join'){
    const data=await fetch('/api/groups/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:val})}).then(r=>r.json());
    if(data.error){err.textContent=data.error;err.style.display='block';return;}
    addGroupItem(data);closeModal();openGroup(data.id,data.name,data.invite_code);
  }
}

function addFriendItem(u){
  document.getElementById('noFriendsMsg')?.remove();
  const list=document.getElementById('dmList');
  const label=u.nickname||u.name;
  const el=document.createElement('div');
  el.className='convo-item';el.id='dm-item-'+u.id;el.dataset.avatar=u.avatar||'';
  el.onclick=()=>openDM(u.id,label,u.avatar||'');
  const avatarContent=u.avatar?`<img src="/uploads/${u.avatar}" style="width:100%;height:100%;object-fit:cover;">`:label[0].toUpperCase();
  el.innerHTML=`<div style="position:relative;flex-shrink:0;"><div class="c-avatar" id="dm-avatar-${u.id}">${avatarContent}</div><div style="position:absolute;bottom:0;right:0;width:10px;height:10px;border-radius:50%;border:2px solid var(--card);background:${u.online?'#22c55e':'#ccc'};"></div></div><div class="convo-info"><div class="convo-name">${esc(label)}</div><div class="convo-preview" id="dm-preview-${u.id}">Click to chat</div></div>`;
  list.prepend(el);
}

function addGroupItem(g){
  document.getElementById('noGroupsMsg')?.remove();
  const inner=document.getElementById('groupListInner');
  const el=document.createElement('div');
  el.className='convo-item';el.id='group-item-'+g.id;
  el.onclick=()=>openGroup(g.id,g.name,g.invite_code);
  el.innerHTML=`<div class="c-avatar group">${g.name.slice(0,2).toUpperCase()}</div><div class="convo-info"><div class="convo-name">${esc(g.name)}</div><div class="convo-preview">Click to open</div></div>`;
  inner.prepend(el);
}

function showToastInbox(msg){
  let t=document.getElementById('inboxToast');
  if(!t){t=document.createElement('div');t.id='inboxToast';t.style.cssText='position:fixed;bottom:25px;right:25px;background:var(--card);color:var(--text);border:1px solid var(--border);padding:12px 18px;border-radius:10px;font-size:.85rem;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.12);z-index:999;display:none;';document.body.appendChild(t);}
  t.textContent=msg;t.style.display='block';
  clearTimeout(t._to);t._to=setTimeout(()=>t.style.display='none',3000);
}

document.getElementById('modalInput').addEventListener('keydown',e=>{if(e.key==='Enter')confirmModal();if(e.key==='Escape')closeModal();});
document.getElementById('modalOverlay').addEventListener('click',e=>{if(e.target===document.getElementById('modalOverlay'))closeModal();});
document.getElementById('nicknameInput').addEventListener('keydown',e=>{if(e.key==='Enter')saveNickname();});
