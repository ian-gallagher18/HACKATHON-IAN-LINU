function esc(t){return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

function showSection(name,el){
  document.querySelectorAll('.profile-section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.pnav').forEach(n=>n.classList.remove('active'));
  document.getElementById('section-'+name).classList.add('active');
  el.classList.add('active');
  if(name==='friends')loadFriendProfiles();
}

function showToast(msg,type='success'){
  const t=document.getElementById('toast');
  t.textContent=msg;t.className='toast '+type;t.style.display='block';
  setTimeout(()=>t.style.display='none',3000);
}

function previewAvatar(input){
  if(!input.files[0])return;
  const url=URL.createObjectURL(input.files[0]);
  ['avatarDisplay','avatarPreview'].forEach(id=>{
    const el=document.getElementById(id);
    el.innerHTML=`<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`;
  });
}

async function removeAvatar(){
  const ok=await customModal({icon:'🗑️',title:'Remove Photo',sub:'Remove your profile picture?',dangerLabel:'Remove',confirmClass:'cm-danger'});
  if(!ok)return;
  const fd=new FormData();fd.append('remove_avatar','true');
  const data=await fetch('/api/profile',{method:'POST',body:fd}).then(r=>r.json());
  if(data.ok){
    const initial=window.USER_INITIAL||'?';
    ['avatarDisplay','avatarPreview'].forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML=initial;});
    showToast('Photo removed');
    document.querySelector('[onclick="removeAvatar()"]')?.remove();
  }else showToast(data.error||'Failed','error');
}

async function savePersonal(){
  const fd=new FormData();
  fd.append('name',document.getElementById('fieldName').value);
  fd.append('nickname',document.getElementById('fieldNickname').value);
  fd.append('bio',document.getElementById('fieldBio').value);
  fd.append('dob',document.getElementById('fieldDob').value);
  const avatarFile=document.getElementById('avatarInput').files[0];
  if(avatarFile)fd.append('avatar',avatarFile);
  const data=await fetch('/api/profile',{method:'POST',body:fd}).then(r=>r.json());
  if(data.ok)showToast('Profile saved!');else showToast(data.error,'error');
}

async function saveSetting(key,value){
  const fd=new FormData();fd.append(key,value.toString());
  const data=await fetch('/api/profile',{method:'POST',body:fd}).then(r=>r.json());
  if(data.ok)showToast('Saved!');
}

function applyDarkMode(isDark){
  const newTheme=isDark?'dark':'light';
  document.body.dataset.theme=newTheme;
  document.documentElement.dataset.theme=newTheme;
  localStorage.setItem('theme',newTheme);
  const btn=document.querySelector('.toggle-btn');
  if(btn)btn.textContent=isDark?'☀️':'🌙';
  const toggle=document.getElementById('settingDarkMode');
  if(toggle)toggle.checked=isDark;
  saveSetting('dark_mode',isDark);
}

function selectColour(el){
  document.querySelectorAll('.colour-swatch').forEach(s=>s.classList.remove('selected'));
  el.classList.add('selected');
  applyColour(el.dataset.colour);
  saveSetting('theme_colour',el.dataset.colour);
}

function customModal({icon,title,sub,inputPlaceholder,confirmLabel,confirmClass,dangerLabel}){
  return new Promise(resolve=>{
    const overlay=document.getElementById('confirmOverlay');
    document.getElementById('cmIcon').textContent=icon||'';
    document.getElementById('cmTitle').textContent=title||'';
    document.getElementById('cmSub').innerHTML=sub||'';
    const err=document.getElementById('cmErr');err.style.display='none';err.textContent='';
    const inp=document.getElementById('cmInput');
    if(inputPlaceholder){
      inp.style.display='block';inp.value='';inp.placeholder=inputPlaceholder;
      inp.type=inputPlaceholder.toLowerCase().includes('password')?'password':'text';
      setTimeout(()=>inp.focus(),80);
    }else inp.style.display='none';
    const btns=document.getElementById('cmBtns');btns.innerHTML='';
    const cancel=document.createElement('button');
    cancel.className='cm-btn cm-cancel';cancel.textContent='Cancel';
    cancel.onclick=()=>{overlay.style.display='none';resolve(null);};btns.appendChild(cancel);
    const ok=document.createElement('button');
    ok.className='cm-btn '+(confirmClass||'cm-confirm');
    ok.textContent=dangerLabel||confirmLabel||'Confirm';
    ok.onclick=()=>{
      if(inputPlaceholder){const val=inp.value.trim();if(!val){err.textContent='This field is required.';err.style.display='block';inp.focus();return;}overlay.style.display='none';resolve(val);}
      else{overlay.style.display='none';resolve(true);}
    };
    inp.onkeydown=e=>{if(e.key==='Enter')ok.click();if(e.key==='Escape')cancel.click();};
    btns.appendChild(ok);overlay.style.display='flex';
  });
}

async function changePassword(){
  const np=document.getElementById('newPw').value;
  const cp=document.getElementById('confirmPw').value;
  if(!np){showToast('Enter a new password','error');return;}
  if(np!==cp){showToast('Passwords do not match','error');return;}
  if(np.length<6){showToast('Password must be at least 6 characters','error');return;}
  const data=await fetch('/api/profile/change-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({current_password:document.getElementById('currentPw').value,new_password:np})}).then(r=>r.json());
  if(data.ok){showToast('Password updated!');['currentPw','newPw','confirmPw'].forEach(id=>document.getElementById(id).value='');}
  else showToast(data.error||'Error updating password','error');
}

async function deleteAccount(){
  const pw=await customModal({icon:'⚠️',title:'Delete Account',sub:'This will permanently delete your account and all your data. Enter your <b>current password</b> to confirm.',inputPlaceholder:'Your password',dangerLabel:'Delete My Account',confirmClass:'cm-danger'});
  if(!pw)return;
  const data=await fetch('/api/profile/delete-account',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pw})}).then(r=>r.json());
  if(data.ok)window.location.href=data.redirect;
  else showToast(data.error||'Incorrect password','error');
}

async function uploadFile(input){
  if(!input.files[0])return;
  const fd=new FormData();fd.append('file',input.files[0]);
  const data=await fetch('/api/files',{method:'POST',body:fd}).then(r=>r.json());
  if(data.id){
    document.getElementById('noFilesMsg')?.remove();
    const item=document.createElement('div');
    item.className='file-item';item.id='file-'+data.id;
    item.innerHTML=`<div class="file-icon-wrap"><i class="fa fa-file"></i></div><div class="file-info"><div class="file-name">${esc(data.original_name)}</div><div class="file-meta">${(data.size/1024).toFixed(1)} KB</div></div><div class="file-actions"><button class="file-btn dl-btn" onclick="window.open('/uploads/${data.filename}')">↓</button><button class="file-btn del-btn" onclick="deleteFile(${data.id})">✕</button></div>`;
    document.getElementById('fileList').prepend(item);
    showToast('File uploaded!');
  }else showToast(data.error||'Upload failed','error');
}

async function deleteFile(id){
  const ok=await customModal({icon:'🗑️',title:'Delete File',sub:'Remove this file? This cannot be undone.',dangerLabel:'Delete',confirmClass:'cm-danger'});
  if(!ok)return;
  const res=await fetch('/api/files/'+id,{method:'DELETE'});
  if((await res.json()).ok){document.getElementById('file-'+id)?.remove();showToast('Deleted');}
}

async function loadFriendProfiles(){
  const grid=document.getElementById('friendsGrid');
  const friends=await fetch('/api/friends/profiles').then(r=>r.json());
  if(!friends.length){grid.innerHTML='<div style="color:var(--subtext);text-align:center;padding:20px 0;">No friends added yet. Add friends from Inbox.</div>';return;}
  grid.innerHTML=friends.map(f=>{
    const label=f.nickname||f.display_name;
    const avatarHtml=f.avatar?`<img src="/uploads/${f.avatar}" style="width:100%;height:100%;object-fit:cover;">`:`<span>${label[0].toUpperCase()}</span>`;
    const dob=f.dob?`🎂 ${f.dob}`:'';
    const joined=f.joined?`📅 Joined ${f.joined}`:'';
    return`<div class="friend-card"><div class="friend-avatar">${avatarHtml}</div><div class="friend-info"><div class="friend-name">${esc(label)} <span class="friend-status ${f.online?'online':''}" title="${f.online?'Online':'Offline'}"></span></div><div class="friend-username">@${esc(f.name)}</div>${f.bio?`<div class="friend-bio">${esc(f.bio)}</div>`:''}<div class="friend-meta">${dob}${dob&&joined?' · ':''}${joined}</div></div></div>`;
  }).join('');
}
