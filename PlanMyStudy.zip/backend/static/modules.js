let modules=[],moduleFiles={},subFiles={};
let _modalResolve=null;

function esc(t){return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}

function showModal(type,context){
  return new Promise(resolve=>{
    _modalResolve=resolve;
    const overlay=document.getElementById('pmsOverlay');
    const icon=document.getElementById('pmsIcon'),title=document.getElementById('pmsTitle');
    const sub=document.getElementById('pmsSub'),inp=document.getElementById('pmsInput');
    const err=document.getElementById('pmsErr'),btns=document.getElementById('pmsBtns');
    err.style.display='none';err.textContent='';inp.value='';
    const configs={
      module:{icon:'📚',title:'Add Module',sub:'Give your new module a name.',placeholder:'e.g. Mathematics',confirm:'Add Module',danger:false},
      submodule:{icon:'📖',title:'Add Submodule',sub:`Adding to: <b>${context||''}</b>`,placeholder:'e.g. Algebra',confirm:'Add Submodule',danger:false},
      delModule:{icon:'🗑️',title:'Delete Module',sub:`Delete <b>${context||''}</b> and all its content? This cannot be undone.`,placeholder:null,confirm:null,danger:true},
      delSub:{icon:'🗑️',title:'Delete Submodule',sub:`Remove <b>${context||''}</b>?`,placeholder:null,confirm:null,danger:true},
    };
    const cfg=configs[type];
    icon.textContent=cfg.icon;title.textContent=cfg.title;sub.innerHTML=cfg.sub;
    if(cfg.placeholder){inp.style.display='block';inp.placeholder=cfg.placeholder;setTimeout(()=>inp.focus(),80);}
    else inp.style.display='none';
    btns.innerHTML='';
    const cancel=document.createElement('button');
    cancel.className='pms-btn-cancel';cancel.textContent='Cancel';
    cancel.onclick=()=>{closeModal();resolve(null);};btns.appendChild(cancel);
    if(cfg.danger){
      const del=document.createElement('button');
      del.className='pms-btn-danger';del.textContent='Delete';
      del.onclick=()=>{closeModal();resolve(true);};btns.appendChild(del);
    }else{
      const ok=document.createElement('button');
      ok.className='pms-btn-confirm';ok.textContent=cfg.confirm;
      ok.onclick=()=>{const val=inp.value.trim();if(!val){err.textContent='Please enter a name.';err.style.display='block';inp.focus();return;}closeModal();resolve(val);};
      btns.appendChild(ok);
      inp.addEventListener('keydown',function onKey(e){
        if(e.key==='Enter'){ok.click();inp.removeEventListener('keydown',onKey);}
        if(e.key==='Escape'){cancel.click();inp.removeEventListener('keydown',onKey);}
      });
    }
    overlay.classList.add('show');
  });
}

function closeModal(){document.getElementById('pmsOverlay').classList.remove('show');}
document.getElementById('pmsOverlay').addEventListener('click',e=>{
  if(e.target===document.getElementById('pmsOverlay')){closeModal();if(_modalResolve)_modalResolve(null);}
});

async function loadModules(){
  modules=await fetch('/api/modules').then(r=>r.json());
  await Promise.all(modules.map(m=>loadModuleFiles(m.id)));
  await Promise.all(modules.flatMap(m=>m.submodules.map(s=>loadSubFiles(s.id))));
  renderModules();
}

async function loadModuleFiles(moduleId){
  moduleFiles[moduleId]=await fetch('/api/module-files/'+moduleId).then(r=>r.json());
}

async function loadSubFiles(subId){
  subFiles[subId]=await fetch('/api/submodule-files/'+subId).then(r=>r.json());
}

function renderModules(){
  const list=document.getElementById('modulesList');list.innerHTML='';
  modules.forEach(mod=>{
    const div=document.createElement('div');
    div.className='mod-module';div.id='module-'+mod.id;
    const header=document.createElement('div');
    header.className='module-header';
    header.innerHTML=`<span>${esc(mod.name)}</span><div class="module-header-actions"><button class="mod-icon-btn small" onclick="addSubmodule(${mod.id},'${esc(mod.name)}')"><i class="fa fa-plus"></i> Sub</button><button class="mod-icon-btn danger small" onclick="deleteModule(${mod.id},'${esc(mod.name)}')"><i class="fa fa-trash"></i></button></div>`;
    const subDiv=document.createElement('div');subDiv.className='mod-submodules';
    mod.submodules.forEach(sub=>{
      const subItem=document.createElement('div');
      subItem.className='mod-submodule';subItem.id='sub-'+sub.id;
      const sfiles=subFiles[sub.id]||[];
      subItem.innerHTML=`<div style="width:100%;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:${sfiles.length?'6px':'0'};"><i class="fa fa-book" style="color:var(--accent);flex-shrink:0"></i><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(sub.name)}</span><label class="upload-label" style="font-size:.68rem;padding:3px 7px;" title="Upload file to ${esc(sub.name)}"><i class="fa fa-upload"></i><input type="file" style="display:none" onchange="uploadSubFile(${sub.id},this)"></label><button class="mod-icon-btn danger small" onclick="deleteSubmodule(${sub.id},'${esc(sub.name)}')"><i class="fa fa-times"></i></button></div><div id="subfile-list-${sub.id}">${sfiles.map(f=>subFileRowHtml(f,sub.id)).join('')}</div></div>`;
      subDiv.appendChild(subItem);
    });
    const filesDiv=document.createElement('div');
    filesDiv.className='module-files-section';filesDiv.id='module-files-'+mod.id;
    const files=moduleFiles[mod.id]||[];
    filesDiv.innerHTML=`<div class="module-files-title"><span>📎 Files (${files.length})</span><label class="upload-label"><i class="fa fa-upload"></i> Upload<input type="file" style="display:none" onchange="uploadModuleFile(${mod.id},this)"></label></div><div id="file-list-${mod.id}">${files.map(f=>fileRowHtml(f,mod.id)).join('')}${files.length===0?'<div style="color:#aaa;font-size:.78rem;padding:4px 0">No files yet</div>':''}</div>`;
    div.appendChild(header);div.appendChild(subDiv);div.appendChild(filesDiv);list.appendChild(div);
  });
}

function _fileIcon(name){
  const ext=name.split('.').pop().toLowerCase();
  return(['jpg','jpeg','png','gif','webp'].includes(ext)?'fa-image':ext==='pdf'?'fa-file-pdf':['doc','docx'].includes(ext)?'fa-file-word':['xls','xlsx'].includes(ext)?'fa-file-excel':['js','css','html','htm'].includes(ext)?'fa-file-code':['zip','rar'].includes(ext)?'fa-file-zipper':'fa-file');
}

function _fmtSize(s){return s<1024?s+' B':s<1048576?(s/1024).toFixed(1)+' KB':(s/1048576).toFixed(1)+' MB';}

function fileRowHtml(f,moduleId){
  return`<div class="file-row" id="mfile-${f.id}"><i class="fa ${_fileIcon(f.original_name)}"></i><span title="${esc(f.original_name)}">${esc(f.original_name)}</span><small style="color:#aaa;flex-shrink:0">${_fmtSize(f.size)}</small><div class="file-row-btns"><button class="file-dl" onclick="window.open('/uploads/${f.filename}')">↓</button><button class="file-del" onclick="deleteModuleFile(${f.id},${moduleId})">✕</button></div></div>`;
}

async function uploadModuleFile(moduleId,input){
  if(!input.files[0])return;
  const fd=new FormData();fd.append('file',input.files[0]);
  const data=await fetch('/api/module-files/'+moduleId,{method:'POST',body:fd}).then(r=>r.json());
  if(data.id){
    if(!moduleFiles[moduleId])moduleFiles[moduleId]=[];
    moduleFiles[moduleId].push(data);
    const listEl=document.getElementById('file-list-'+moduleId);
    if(listEl){listEl.querySelector('[style*="No files"]')?.remove();listEl.insertAdjacentHTML('beforeend',fileRowHtml(data,moduleId));}
    const titleEl=document.querySelector(`#module-files-${moduleId} .module-files-title span`);
    if(titleEl)titleEl.textContent=`📎 Files (${moduleFiles[moduleId].length})`;
  }
  input.value='';
}

async function deleteModuleFile(fileId,moduleId){
  await fetch('/api/module-files/file/'+fileId,{method:'DELETE'});
  moduleFiles[moduleId]=(moduleFiles[moduleId]||[]).filter(f=>f.id!==fileId);
  document.getElementById('mfile-'+fileId)?.remove();
  const titleEl=document.querySelector(`#module-files-${moduleId} .module-files-title span`);
  if(titleEl)titleEl.textContent=`📎 Files (${moduleFiles[moduleId].length})`;
}

function subFileRowHtml(f,subId){
  return`<div class="file-row" id="sfile-${f.id}" style="margin-left:20px;"><i class="fa ${_fileIcon(f.original_name)}"></i><span title="${esc(f.original_name)}">${esc(f.original_name)}</span><small style="color:#aaa;flex-shrink:0">${_fmtSize(f.size)}</small><div class="file-row-btns"><button class="file-dl" onclick="window.open('/uploads/${f.filename}')">↓</button><button class="file-del" onclick="deleteSubFile(${f.id},${subId})">✕</button></div></div>`;
}

async function uploadSubFile(subId,input){
  if(!input.files[0])return;
  const fd=new FormData();fd.append('file',input.files[0]);
  const data=await fetch('/api/submodule-files/'+subId,{method:'POST',body:fd}).then(r=>r.json());
  if(data.id){
    if(!subFiles[subId])subFiles[subId]=[];
    subFiles[subId].push(data);
    document.getElementById('subfile-list-'+subId)?.insertAdjacentHTML('beforeend',subFileRowHtml(data,subId));
  }
  input.value='';
}

async function deleteSubFile(fileId,subId){
  await fetch('/api/submodule-files/file/'+fileId,{method:'DELETE'});
  subFiles[subId]=(subFiles[subId]||[]).filter(f=>f.id!==fileId);
  document.getElementById('sfile-'+fileId)?.remove();
}

async function addModule(){
  const name=await showModal('module');if(!name)return;
  const mod=await fetch('/api/modules',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}).then(r=>r.json());
  modules.push(mod);moduleFiles[mod.id]=[];renderModules();
}

async function deleteModule(id,name){
  const ok=await showModal('delModule',name);if(!ok)return;
  await fetch('/api/modules/'+id,{method:'DELETE'});
  modules=modules.filter(m=>m.id!==id);renderModules();
}

async function addSubmodule(moduleId,moduleName){
  const name=await showModal('submodule',moduleName);if(!name)return;
  const sub=await fetch(`/api/modules/${moduleId}/submodules`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}).then(r=>r.json());
  subFiles[sub.id]=[];
  const mod=modules.find(m=>m.id===moduleId);
  if(mod){mod.submodules.push(sub);renderModules();}
}

async function deleteSubmodule(subId,name){
  const ok=await showModal('delSub',name);if(!ok)return;
  await fetch('/api/submodules/'+subId,{method:'DELETE'});
  modules.forEach(m=>{m.submodules=m.submodules.filter(s=>s.id!==subId);});
  renderModules();
}

loadModules();
