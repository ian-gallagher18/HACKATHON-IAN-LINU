// Apply theme + colour immediately on <html> before body paints
(function() {
  const colour = localStorage.getItem('colour') || 'mint';
  const theme  = localStorage.getItem('theme')  || 'light';
  document.documentElement.dataset.colour = colour;
  if (theme === 'dark') document.documentElement.dataset.theme = 'dark';
})();

document.addEventListener('DOMContentLoaded', function() {
  const colour = localStorage.getItem('colour') || 'mint';
  const theme  = localStorage.getItem('theme')  || 'light';
  document.body.dataset.colour = colour;
  if (theme === 'dark') document.body.dataset.theme = 'dark';

  // Sync sidebar button
  const btn = document.querySelector('.toggle-btn');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';

  // Sync profile page dark mode toggle if present
  const toggle = document.getElementById('settingDarkMode');
  if (toggle) toggle.checked = (theme === 'dark');

  // Inbox badge
  if (localStorage.getItem('inbox_unread') === '1') {
    const badge = document.getElementById('inboxBadge');
    if (badge) badge.classList.add('show');
  }

  // Socket for global toast notifications (non-inbox pages)
  if (window.ME_ID && window.io && !window._notifConnected) {
    window._notifConnected = true;
    const isInbox = window.location.pathname === '/inbox';
    const isStudy = window.location.pathname === '/sessions';
    const ns = io();
    ns.on('connect', () => ns.emit('join_notif'));
    ns.on('new_notif', data => {
      localStorage.setItem('inbox_unread', '1');
      const badge = document.getElementById('inboxBadge');
      if (badge) badge.classList.add('show');
      // Show toast on all pages except inbox (handles its own) and study sessions (focus mode)
      if (!isInbox && !isStudy) {
        showGlobalToast(data);
      }
    });
    ns.on('new_dm', data => {
      if (!isInbox) {
        localStorage.setItem('inbox_unread', '1');
        const badge = document.getElementById('inboxBadge');
        if (badge) badge.classList.add('show');
        showGlobalToast({ type: 'message', from: data.sender_name, body: data.body || '📎 File' });
      }
    });
  }
});

function showGlobalToast(data) {
  let container = document.getElementById('globalToastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'globalToastContainer';
    container.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.style.cssText = `
    background:var(--card);
    color:var(--text);
    border:1px solid var(--border);
    border-left:4px solid var(--accent);
    border-radius:12px;
    padding:12px 16px;
    min-width:240px;
    max-width:300px;
    box-shadow:0 8px 24px rgba(0,0,0,0.15);
    font-family:"Nunito",sans-serif;
    font-size:0.84rem;
    pointer-events:all;
    cursor:pointer;
    animation:toastIn 0.25s ease;
    display:flex;
    align-items:flex-start;
    gap:10px;
  `;

  const icon = data.type === 'friend_request' ? '👋'
    : data.type === 'friend_accept' ? '✅'
    : data.type === 'group_message' ? '👥'
    : '💬';

  const title = data.type === 'friend_request' ? 'Friend Request'
    : data.type === 'friend_accept' ? 'Friend Accepted'
    : data.type === 'group_message' ? data.group_name || 'Group Message'
    : data.from || 'New Message';

  const body = data.body || (data.type === 'friend_request' ? `${data.from} wants to be friends` : '');

  toast.innerHTML = `
    <span style="font-size:1.3rem;flex-shrink:0;line-height:1.2">${icon}</span>
    <div style="flex:1;min-width:0;">
      <div style="font-weight:700;font-family:'Poppins',sans-serif;font-size:0.82rem;margin-bottom:2px;">${esc(title)}</div>
      ${body ? `<div style="color:var(--subtext);font-size:0.78rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(body)}</div>` : ''}
    </div>
  `;

  toast.onclick = () => window.location.href = '/inbox';
  container.appendChild(toast);

  // Animate out and remove
  setTimeout(() => {
    toast.style.transition = 'opacity 0.3s, transform 0.3s';
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function esc(t) { return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// Add keyframe for toast animation
const _style = document.createElement('style');
_style.textContent = '@keyframes toastIn { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:translateX(0)} }';
document.head.appendChild(_style);

function toggleDark() {
  const isDark = document.body.dataset.theme === 'dark';
  const newTheme = isDark ? 'light' : 'dark';
  document.body.dataset.theme = newTheme;
  document.documentElement.dataset.theme = newTheme;
  localStorage.setItem('theme', newTheme);
  const btn = document.querySelector('.toggle-btn');
  if (btn) btn.textContent = newTheme === 'dark' ? '☀️' : '🌙';
  // Sync profile toggle if present
  const toggle = document.getElementById('settingDarkMode');
  if (toggle) toggle.checked = (newTheme === 'dark');
}

function applyColour(colour) {
  document.body.dataset.colour = colour;
  document.documentElement.dataset.colour = colour;
  localStorage.setItem('colour', colour);
}
