let current=new Date(),selectedDate=null,events={},allModules=[];
const calEl=document.getElementById('calendar');
const monthYearEl=document.getElementById('monthYear');
const today=new Date();today.setHours(0,0,0,0);

async function init(){
  const[evData,modData]=await Promise.all([
    fetch('/api/calendar').then(r=>r.json()),
    fetch('/api/modules').then(r=>r.json())
  ]);
  events=evData;allModules=modData;
  populateModuleSelect();renderCalendar();renderUpcoming();
}

function populateModuleSelect(){
  const sel=document.getElementById('moduleSelect');
  sel.innerHTML='<option value="">No module</option>';
  allModules.forEach(m=>{
    const o=document.createElement('option');
    o.value=m.id;o.textContent=m.name;sel.appendChild(o);
  });
  populateSubmodules();
}

function populateSubmodules(){
  const modId=parseInt(document.getElementById('moduleSelect').value);
  const sel=document.getElementById('submoduleSelect');
  sel.innerHTML='<option value="">No submodule</option>';
  const mod=allModules.find(m=>m.id===modId);
  if(mod&&mod.submodules&&mod.submodules.length){
    mod.submodules.forEach(s=>{
      const o=document.createElement('option');
      o.value=s.id;o.textContent=s.name;sel.appendChild(o);
    });
    sel.style.display='';
  }else{sel.style.display='none';}
}

function renderCalendar(){
  calEl.innerHTML='';
  const y=current.getFullYear(),m=current.getMonth();
  monthYearEl.textContent=current.toLocaleString('default',{month:'long',year:'numeric'});
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d=>{
    const div=document.createElement('div');
    div.className='day-name';div.textContent=d;calEl.appendChild(div);
  });
  const firstDay=new Date(y,m,1).getDay();
  const totalDays=new Date(y,m+1,0).getDate();
  for(let i=0;i<firstDay;i++)calEl.appendChild(document.createElement('div'));
  for(let d=1;d<=totalDays;d++){
    const key=`${y}-${m}-${d}`;
    const dt=new Date(y,m,d);
    const isToday=dt.getTime()===today.getTime();
    const isSelected=key===selectedDate;
    const dayDiv=document.createElement('div');
    dayDiv.className='cal-day'+(isToday?' today':'')+(isSelected?' selected':'');
    dayDiv.dataset.key=key;
    dayDiv.onclick=()=>selectDate(key,dayDiv);
    const num=document.createElement('div');
    num.className='day-number';num.textContent=d;dayDiv.appendChild(num);
    if(events[key]){
      events[key].slice(0,2).forEach(e=>{
        const chip=document.createElement('div');
        chip.className='cal-event-chip';
        chip.innerHTML=`<span>${esc(e.text)}</span><button class="delete-btn" onclick="event.stopPropagation();deleteEvent(${e.id},'${key}')">✕</button>`;
        dayDiv.appendChild(chip);
      });
      if(events[key].length>2){
        const more=document.createElement('div');
        more.style.cssText='font-size:.6rem;color:var(--subtext);padding:0 2px;';
        more.textContent=`+${events[key].length-2} more`;
        dayDiv.appendChild(more);
      }
    }
    calEl.appendChild(dayDiv);
  }
}

function selectDate(key,el){
  document.querySelectorAll('.cal-day.selected').forEach(d=>d.classList.remove('selected'));
  if(selectedDate===key){
    selectedDate=null;
    document.getElementById('selectedHint').textContent='← Pick a date first';
  }else{
    selectedDate=key;el.classList.add('selected');
    const parts=key.split('-');
    const dt=new Date(+parts[0],+parts[1],+parts[2]);
    document.getElementById('selectedHint').textContent=dt.toLocaleDateString('default',{day:'numeric',month:'short',year:'numeric'});
    document.getElementById('eventInput').focus();
  }
}

function changeMonth(n){current.setMonth(current.getMonth()+n);renderCalendar();}

async function addEvent(){
  const inp=document.getElementById('eventInput');
  const modId=document.getElementById('moduleSelect').value||null;
  const subId=document.getElementById('submoduleSelect').value||null;
  if(!selectedDate||!inp.value.trim()){
    if(!selectedDate)document.getElementById('selectedHint').textContent='← Pick a date first';
    return;
  }
  const res=await fetch('/api/calendar',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({date_key:selectedDate,text:inp.value.trim(),
      module_id:modId?parseInt(modId):null,submodule_id:subId?parseInt(subId):null})
  });
  const e=await res.json();
  if(!events[selectedDate])events[selectedDate]=[];
  events[selectedDate].push(e);
  inp.value='';renderCalendar();renderUpcoming();
  const dayEl=document.querySelector(`.cal-day[data-key="${selectedDate}"]`);
  if(dayEl)dayEl.classList.add('selected');
}

async function deleteEvent(id,key){
  await fetch('/api/calendar/'+id,{method:'DELETE'});
  events[key]=events[key].filter(e=>e.id!==id);
  if(!events[key].length)delete events[key];
  renderCalendar();renderUpcoming();
  if(selectedDate){
    const dayEl=document.querySelector(`.cal-day[data-key="${selectedDate}"]`);
    if(dayEl)dayEl.classList.add('selected');
  }
}

function renderUpcoming(){
  const list=document.getElementById('upcomingList');
  const flat=[];
  Object.entries(events).forEach(([key,evs])=>{
    const parts=key.split('-');
    const dt=new Date(+parts[0],+parts[1],+parts[2]);
    evs.forEach(e=>flat.push({...e,dt,key}));
  });
  flat.sort((a,b)=>a.dt-b.dt);
  const upcoming=flat.filter(e=>e.dt>=today);
  const past=flat.filter(e=>e.dt<today).reverse();
  const sorted=[...upcoming,...past];
  if(!sorted.length){list.innerHTML='<div class="empty-upcoming">No events yet — click a date to add one!</div>';return;}
  list.innerHTML='';
  sorted.forEach(e=>{
    const daysDiff=Math.round((e.dt-today)/86400000);
    let badge,badgeClass;
    if(daysDiff===0){badge='Today';badgeClass='today';}
    else if(daysDiff===1){badge='Tomorrow';badgeClass='future';}
    else if(daysDiff>1){badge=`In ${daysDiff}d`;badgeClass='future';}
    else if(daysDiff===-1){badge='Yesterday';badgeClass='overdue';}
    else{badge=`${Math.abs(daysDiff)}d ago`;badgeClass='overdue';}
    const dateStr=e.dt.toLocaleDateString('default',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
    const filesHtml=(e.files&&e.files.length)?`<div class="upcoming-files">${e.files.map(f=>{
      const sz=f.size<1048576?(f.size/1024).toFixed(1)+' KB':(f.size/1048576).toFixed(1)+' MB';
      return`<div class="upcoming-file" onclick="window.open('/uploads/${f.filename}')"><i class="fa ${fileIconClass(f.original_name)}"></i><span class="fn">${esc(f.original_name)}</span><small style="color:var(--subtext);flex-shrink:0">${sz}</small></div>`;
    }).join('')}</div>`:'';
    const moduleHtml=e.module_name?`<div class="upcoming-module"><i class="fa fa-book" style="font-size:.7rem"></i>${esc(e.module_name)}${e.submodule_name?' › '+esc(e.submodule_name):''}</div>`:'';
    const item=document.createElement('div');
    item.className='upcoming-item'+(badgeClass==='overdue'?' overdue-item':'');
    item.innerHTML=`<div class="upcoming-header"><div style="flex:1;min-width:0;"><div class="upcoming-title">${esc(e.text)}</div><div class="upcoming-date">${dateStr}</div>${moduleHtml}</div><div style="display:flex;align-items:center;gap:6px;flex-shrink:0;"><span class="upcoming-badge ${badgeClass}">${badge}</span><button class="upcoming-del" onclick="deleteEvent(${e.id},'${e.key}')">✕</button></div></div>${filesHtml}`;
    list.appendChild(item);
  });
}

function fileIconClass(name){
  const ext=(name||'').split('.').pop().toLowerCase();
  return{pdf:'fa-file-pdf',doc:'fa-file-word',docx:'fa-file-word',xls:'fa-file-excel',xlsx:'fa-file-excel',
    png:'fa-image',jpg:'fa-image',jpeg:'fa-image',gif:'fa-image',webp:'fa-image',
    mp4:'fa-file-video',mp3:'fa-file-audio',zip:'fa-file-zipper'}[ext]||'fa-file';
}

function esc(t){return String(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

document.getElementById('eventInput').addEventListener('keydown',e=>{if(e.key==='Enter')addEvent();});
init();
